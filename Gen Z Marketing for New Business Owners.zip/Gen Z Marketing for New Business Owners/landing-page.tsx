import { useState, useEffect } from 'react'
import { ChevronDown, RefreshCcw, TrendingUp, Share2, Send } from 'lucide-react'

export default function LandingPage() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  useEffect(() => {
    document.documentElement.style.scrollBehavior = 'smooth'
    return () => {
      document.documentElement.style.scrollBehavior = 'auto'
    }
  }, [])

  return (
    <div className="min-h-screen bg-black text-white">
      <header className="container mx-auto px-4 py-6 flex justify-between items-center">
        <div className="text-2xl font-bold">BizBoost</div>
        <nav className="hidden md:flex space-x-6">
          <a href="#home" className="hover:text-purple-400 transition-colors">Home</a>
          <a href="#services" className="hover:text-purple-400 transition-colors">Services</a>
          <a href="#about" className="hover:text-purple-400 transition-colors">About</a>
          <a href="#contact" className="hover:text-purple-400 transition-colors">Contact</a>
        </nav>
        <button
          className="md:hidden text-white p-2"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          <ChevronDown className={`h-6 w-6 transition-transform ${isMenuOpen ? 'rotate-180' : ''}`} />
        </button>
      </header>

      {isMenuOpen && (
        <div className="md:hidden bg-gray-900 py-4">
          <nav className="flex flex-col items-center space-y-4">
            <a href="#home" className="hover:text-purple-400 transition-colors">Home</a>
            <a href="#services" className="hover:text-purple-400 transition-colors">Services</a>
            <a href="#about" className="hover:text-purple-400 transition-colors">About</a>
            <a href="#contact" className="hover:text-purple-400 transition-colors">Contact</a>
          </nav>
        </div>
      )}

      <main>
        <section id="home" className="container mx-auto px-4 py-20 text-center">
          <h1 className="text-5xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-purple-400 to-pink-600 text-transparent bg-clip-text">
            Modernize Your Newly Acquired Business
          </h1>
          <p className="text-xl md:text-2xl mb-10 max-w-2xl mx-auto text-gray-300">
            Bridge the generational gap and transform your traditional business into a digital powerhouse. We help new owners like you adapt and thrive in the modern market.
          </p>
          <a 
            href="https://calendly.com/juvensenjules" 
            target="_blank" 
            rel="noopener noreferrer" 
            className="inline-block px-6 py-3 bg-purple-600 hover:bg-purple-700 text-white font-semibold rounded-md transition-colors"
          >
            Start Your Transformation
          </a>
        </section>

        <section id="services" className="bg-gray-900 py-20">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center">Our Services</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <ServiceCard
                icon={<RefreshCcw className="h-10 w-10 text-yellow-400" />}
                title="Business Modernization"
                description="Update your traditional business model to meet the demands of today's market."
              />
              <ServiceCard
                icon={<TrendingUp className="h-10 w-10 text-green-400" />}
                title="Digital Marketing Strategies"
                description="Implement cutting-edge digital marketing tactics to reach new, younger audiences."
              />
              <ServiceCard
                icon={<Share2 className="h-10 w-10 text-blue-400" />}
                title="Brand Rejuvenation"
                description="Refresh your brand identity to appeal to both loyal customers and new generations."
              />
            </div>
          </div>
        </section>

        <section id="about" className="container mx-auto px-4 py-20">
          <div className="bg-gray-800 rounded-lg p-8 md:p-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-center">About Us</h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto text-center mb-8">
              At BizBoost, we specialize in helping entrepreneurs who have recently acquired businesses from the boomer generation. Our team of experts understands the unique challenges you face in modernizing traditional businesses and bridging the generational gap. We combine your industry experience with our digital expertise to create a powerful strategy for success in today's market.
            </p>
            <div className="text-center">
              <a 
                href="https://calendly.com/juvensenjules" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="inline-flex items-center px-6 py-3 bg-pink-600 hover:bg-pink-700 text-white font-semibold rounded-md transition-colors"
              >
                <Send className="mr-2 h-5 w-5" /> Schedule a Consultation
              </a>
            </div>
          </div>
        </section>

        <section id="contact" className="bg-gray-900 py-20">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center">Contact Us</h2>
            <div className="text-center">
              <p className="text-xl mb-6">Ready to start your business transformation?</p>
              <p className="text-lg mb-8">Get in touch with us to schedule a consultation or learn more about our services.</p>
              <a 
                href="https://calendly.com/juvensenjules" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="inline-flex items-center px-6 py-3 bg-pink-600 hover:bg-pink-700 text-white font-semibold rounded-md transition-colors"
              >
                <Send className="mr-2 h-5 w-5" /> Schedule a Consultation
              </a>
              <p className="mt-8 text-gray-400">
                Email: info@bizboost.com<br />
                Phone: (555) 123-4567
              </p>
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-gray-900 py-10 border-t border-gray-800">
        <div className="container mx-auto px-4 text-center text-gray-400">
          <p>&copy; 2023 BizBoost Marketing Agency. All rights reserved.</p>
          <p className="mt-2 text-sm">Bridging generations, boosting businesses.</p>
        </div>
      </footer>
    </div>
  )
}

function ServiceCard({ icon, title, description }) {
  return (
    <div className="bg-gray-800 p-6 rounded-lg text-center hover:bg-gray-700 transition-colors">
      <div className="mb-4 flex justify-center">{icon}</div>
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-gray-400">{description}</p>
    </div>
  )
}